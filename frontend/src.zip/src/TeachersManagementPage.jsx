import React, { useEffect, useState } from 'react';
import { Download, Trash2, Users, Save, Edit3, CheckCircle2, X, Search } from 'lucide-react';
import ExcelJS from 'exceljs';
import { api } from './schedule';
import { TEACHER_TYPES, teacherTypeLabel } from './catalog';
import FormError from './FormError';

const emptyTeacherForm = {
  teacherId: '',
  teacherName: '',
  departmentId: '',
  teacherType: 'GIANG_VIEN',
  selectedCodes: [],
};

export default function TeachersManagementPage() {
  const [schoolId, setSchoolId] = useState('PTIT');
  const [departments, setDepartments] = useState([]);
  const [allSubjects, setAllSubjects] = useState([]);
  const [savedTeachers, setSavedTeachers] = useState([]);
  const [filterDeptId, setFilterDeptId] = useState('');
  const [filterCourseCode, setFilterCourseCode] = useState('');
  const [subjectSearch, setSubjectSearch] = useState('');

  const [teacherForm, setTeacherForm] = useState(emptyTeacherForm);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [infoMessage, setInfoMessage] = useState('');

  const school = schoolId.trim();

  useEffect(() => {
    if (!school) return;
    loadData(school);
  }, [school]);

  async function loadData(code) {
    setError('');
    try {
      const [deptsData, subsData, teachersData] = await Promise.all([
        api(`/departments?schoolId=${encodeURIComponent(code)}`),
        api(`/subjects?schoolId=${encodeURIComponent(code)}`),
        api(`/teacher-subjects?schoolId=${encodeURIComponent(code)}`),
      ]);
      const deptList = Array.isArray(deptsData) ? deptsData : [];
      setDepartments(deptList);
      setAllSubjects(Array.isArray(subsData) ? subsData : []);
      setSavedTeachers(Array.isArray(teachersData) ? teachersData : []);
      setTeacherForm(prev => (
        prev.departmentId || !deptList.length ? prev : { ...prev, departmentId: String(deptList[0].id) }
      ));
    } catch (err) {
      setError(err.message);
    }
  }

  const departmentSubjects = allSubjects.filter(
    s => String(s.departmentId) === String(teacherForm.departmentId)
  );

  const departmentCodes = new Set(departmentSubjects.map(s => s.courseCode.toUpperCase()));

  const visibleSubjectChoices = departmentSubjects.filter(s => {
    if (!subjectSearch.trim()) return true;
    const q = subjectSearch.toLocaleLowerCase('vi');
    return `${s.courseCode} ${s.courseName}`.toLocaleLowerCase('vi').includes(q);
  });

  const selectedInDepartment = teacherForm.selectedCodes.filter(c => departmentCodes.has(c.toUpperCase()));

  function handleDepartmentChange(newDeptId) {
    const allowed = new Set(
      allSubjects
        .filter(s => String(s.departmentId) === String(newDeptId))
        .map(s => s.courseCode.toUpperCase())
    );
    setSubjectSearch('');
    setTeacherForm(prev => ({
      ...prev,
      departmentId: newDeptId,
      selectedCodes: prev.selectedCodes.filter(c => allowed.has(c.toUpperCase())),
    }));
  }

  function handleTeacherIdChange(val) {
    const upper = val.toUpperCase();
    const existing = savedTeachers.find(t => t.teacherId.toUpperCase() === upper.trim());
    if (existing) {
      setTeacherForm({
        teacherId: existing.teacherId,
        teacherName: existing.teacherName || '',
        departmentId: existing.departmentId ? String(existing.departmentId) : (departments[0]?.id ? String(departments[0].id) : ''),
        teacherType: existing.teacherType || 'GIANG_VIEN',
        selectedCodes: (existing.subjects || []).map(s => s.courseCode.toUpperCase()),
      });
    } else {
      setTeacherForm(prev => ({ ...prev, teacherId: val }));
    }
  }

  function toggleSubjectCode(code) {
    const upper = code.toUpperCase();
    setTeacherForm(prev => {
      const exists = prev.selectedCodes.some(c => c.toUpperCase() === upper);
      return {
        ...prev,
        selectedCodes: exists
          ? prev.selectedCodes.filter(c => c.toUpperCase() !== upper)
          : [...prev.selectedCodes, upper],
      };
    });
  }

  function selectAllVisibleSubjects() {
    const toAdd = visibleSubjectChoices.map(s => s.courseCode.toUpperCase());
    setTeacherForm(prev => {
      const merged = new Set([...prev.selectedCodes.map(c => c.toUpperCase()), ...toAdd]);
      return { ...prev, selectedCodes: [...merged] };
    });
  }

  function clearVisibleSubjects() {
    const toRemove = new Set(visibleSubjectChoices.map(s => s.courseCode.toUpperCase()));
    setTeacherForm(prev => ({
      ...prev,
      selectedCodes: prev.selectedCodes.filter(c => !toRemove.has(c.toUpperCase())),
    }));
  }

  async function handleSaveTeacher(e) {
    e.preventDefault();
    if (busy) return;
    setError('');
    setInfoMessage('');
    try {
      if (!teacherForm.departmentId) throw new Error('Vui lòng chọn Bộ môn cho giảng viên.');
      if (!selectedInDepartment.length) throw new Error('Vui lòng tích chọn ít nhất 1 môn học thuộc bộ môn.');

      setBusy(true);
      const selectedSet = new Set(selectedInDepartment.map(c => c.toUpperCase()));
      const subjectsPayload = departmentSubjects
        .filter(s => selectedSet.has(s.courseCode.toUpperCase()))
        .map(s => ({
          id: null,
          courseCode: s.courseCode,
          courseName: s.courseName,
          cohort: '*',
          theoryWeight: 1,
          practiceWeight: 1,
          kind: 'PRIMARY',
        }));

      const res = await api('/teacher-subjects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          teacherId: teacherForm.teacherId,
          teacherName: teacherForm.teacherName,
          teacherType: teacherForm.teacherType,
          schoolCode: school,
          departmentId: Number(teacherForm.departmentId),
          subjects: subjectsPayload,
        }),
      });

      // Nếu giảng viên đang sửa có các môn cũ trong cùng bộ môn bị bỏ tích, gỡ bỏ để khớp danh sách vừa chọn.
      const existing = savedTeachers.find(
        t => t.teacherId.toUpperCase() === teacherForm.teacherId.trim().toUpperCase()
      );
      if (existing?.subjects?.length) {
        const toDelete = existing.subjects.filter(
          s => s.id && departmentCodes.has(s.courseCode.toUpperCase()) && !selectedSet.has(s.courseCode.toUpperCase())
        );
        for (const item of toDelete) {
          await api(`/teacher-subjects/${item.id}`, { method: 'DELETE' });
        }
      }

      setInfoMessage(
        `Đã lưu GV ${res.teacherId} (${res.teacherName}) với ${subjectsPayload.length} môn — Bộ môn: ${res.departmentName || ''} | Loại: ${teacherTypeLabel(res.teacherType)} | Tài khoản: ${res.username} | Mật khẩu mặc định: ${res.defaultPassword}`
      );
      setSubjectSearch('');
      setTeacherForm({
        ...emptyTeacherForm,
        departmentId: teacherForm.departmentId,
      });
      await loadData(school);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleDeleteTeacherAssignment(id) {
    if (!window.confirm('Gỡ môn học này khỏi danh sách môn có thể dạy của giảng viên?')) return;
    setError('');
    setInfoMessage('');
    try {
      await api(`/teacher-subjects/${id}`, { method: 'DELETE' });
      setInfoMessage('Đã gỡ môn học khỏi giảng viên.');
      await loadData(school);
    } catch (err) {
      setError(err.message);
    }
  }

  async function exportTeacherAccountsToExcel() {
    if (!visibleTeachers.length) return;
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('TaiKhoanGiangVien');

    sheet.addRow(['STT', 'Mã GV', 'Họ và tên', 'Bộ môn', 'Loại GV', 'Tài khoản', 'Mật khẩu mặc định', 'Các môn có thể dạy']);
    sheet.getRow(1).font = { bold: true };

    visibleTeachers.forEach((t, idx) => {
      const subList = (t.subjects || [])
        .map(s => `${s.courseCode} - ${s.courseName || ''}`)
        .join('; ');
      sheet.addRow([
        idx + 1,
        t.teacherId,
        t.teacherName,
        t.departmentName || 'Chưa xếp bộ môn',
        teacherTypeLabel(t.teacherType),
        t.username || t.teacherId,
        t.defaultPassword || '',
        subList,
      ]);
    });

    sheet.columns = [{ width: 6 }, { width: 14 }, { width: 24 }, { width: 24 }, { width: 16 }, { width: 16 }, { width: 24 }, { width: 52 }];

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `danh-sach-tai-khoan-giang-vien-${school}.xlsx`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  const filterSubjectOptions = filterDeptId
    ? allSubjects.filter(s => String(s.departmentId) === String(filterDeptId))
    : allSubjects;

  const visibleTeachers = savedTeachers.filter(t => {
    if (filterDeptId && String(t.departmentId) !== String(filterDeptId)) return false;
    if (filterCourseCode && !(t.subjects || []).some(s => s.courseCode?.toUpperCase() === filterCourseCode.toUpperCase())) return false;
    return true;
  });

  return (
    <section className="standalone-panel import-panel">
      <div className="panel-title">
        <div>
          <h2>Quản lý Giảng viên của Khoa</h2>
          <p className="muted-text">
            Gắn giảng viên vào Bộ môn, chọn vai trò (Trưởng bộ môn tự động được cấp quyền phân công), và tích chọn nhiều môn giảng viên có thể giảng dạy cùng lúc.
          </p>
        </div>
        <label className="catalog-school">
          Mã Khoa
          <input value={schoolId} onChange={e => setSchoolId(e.target.value)} maxLength={50} />
        </label>
      </div>

      <FormError message={error} />
      {infoMessage && <div role="status" className="info-banner catalog-info"><CheckCircle2 size={18} /> {infoMessage}</div>}

      <div className="catalog-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
          <h3><Users size={18} /> Thêm / Cập nhật Giảng viên ({visibleTeachers.length})</h3>
          <button type="button" className="button primary compact" disabled={!visibleTeachers.length} onClick={exportTeacherAccountsToExcel}>
            <Download size={15} /> Xuất Excel Tài khoản GV (.xlsx)
          </button>
        </div>

        {!departments.length && (
          <p className="import-warning">
            Khoa chưa có bộ môn nào. Vui lòng vào trang <strong>Bộ môn &amp; Môn học</strong> tạo bộ môn và môn học trước.
          </p>
        )}

        <form onSubmit={handleSaveTeacher} style={{ marginTop: '0.75rem', background: '#f8fafc', padding: '1rem', borderRadius: '8px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '0.75rem', marginBottom: '1rem' }}>
            <label>
              Mã giảng viên
              <input required placeholder="VD: GV02" value={teacherForm.teacherId} onChange={e => handleTeacherIdChange(e.target.value)} />
            </label>
            <label>
              Họ tên giảng viên
              <input required placeholder="VD: Nguyễn Văn Minh" value={teacherForm.teacherName} onChange={e => setTeacherForm({ ...teacherForm, teacherName: e.target.value })} />
            </label>
            <label>
              Bộ môn
              <select required value={teacherForm.departmentId} onChange={e => handleDepartmentChange(e.target.value)}>
                <option value="">-- Chọn bộ môn --</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.code} — {d.name}</option>
                ))}
              </select>
            </label>
            <label>
              Loại giảng viên
              <select value={teacherForm.teacherType} onChange={e => setTeacherForm({ ...teacherForm, teacherType: e.target.value })}>
                {TEACHER_TYPES.map(([val, label]) => (
                  <option key={val} value={val}>{label}</option>
                ))}
              </select>
            </label>
          </div>

          <div className="subject-picker-header">
            <div>
              <h4 style={{ margin: 0 }}>Chọn các môn học thuộc bộ môn giảng viên có thể dạy</h4>
              <small className="muted-text">
                Đã chọn <strong>{selectedInDepartment.length}</strong> / {departmentSubjects.length} môn trong bộ môn
              </small>
            </div>
            {departmentSubjects.length > 0 && (
              <div className="subject-picker-actions">
                <label className="search-field" style={{ background: '#fff', minWidth: '180px' }}>
                  <Search size={14} />
                  <input
                    placeholder="Lọc nhanh tên/mã môn…"
                    value={subjectSearch}
                    onChange={e => setSubjectSearch(e.target.value)}
                  />
                </label>
                <button type="button" className="button compact" onClick={selectAllVisibleSubjects}>
                  Chọn tất cả
                </button>
                <button type="button" className="button compact" onClick={clearVisibleSubjects} disabled={!selectedInDepartment.length}>
                  Bỏ chọn
                </button>
              </div>
            )}
          </div>

          {!teacherForm.departmentId ? (
            <p className="muted-text" style={{ marginTop: '0.5rem' }}>Vui lòng chọn Bộ môn để hiện danh sách môn học.</p>
          ) : !departmentSubjects.length ? (
            <p className="muted-text" style={{ marginTop: '0.5rem' }}>
              Bộ môn này chưa có môn học nào. Hãy thêm môn tại trang Bộ môn &amp; Môn học trước.
            </p>
          ) : (
            <div className="subject-checklist">
              {!visibleSubjectChoices.length && (
                <p className="muted-text" style={{ gridColumn: '1 / -1', margin: 0 }}>
                  Không tìm thấy môn học phù hợp với từ khóa "{subjectSearch}".
                </p>
              )}
              {visibleSubjectChoices.map(s => {
                const checked = selectedInDepartment.some(c => c.toUpperCase() === s.courseCode.toUpperCase());
                return (
                  <label key={s.id} className={`subject-check-item${checked ? ' checked' : ''}`}>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleSubjectCode(s.courseCode)}
                    />
                    <span>
                      <code>{s.courseCode}</code>
                      <strong>{s.courseName}</strong>
                    </span>
                  </label>
                );
              })}
            </div>
          )}

          <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.9rem', flexWrap: 'wrap' }}>
            <button type="submit" className="button primary compact" disabled={busy || !departmentSubjects.length || !selectedInDepartment.length}>
              <Save size={14} /> {busy ? 'Đang lưu…' : `Lưu Giảng viên & ${selectedInDepartment.length} môn đã chọn`}
            </button>
            {(teacherForm.teacherId || selectedInDepartment.length > 0) && (
              <button
                type="button"
                className="button compact"
                onClick={() => {
                  setSubjectSearch('');
                  setTeacherForm({ ...emptyTeacherForm, departmentId: departments[0]?.id ? String(departments[0].id) : '' });
                }}
              >
                <X size={14} /> Làm mới form
              </button>
            )}
          </div>
        </form>

        <div className="filter-bar" style={{ padding: '1rem 0 0', flexWrap: 'wrap' }}>
          <label style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: '0.5rem' }}>
            Lọc theo bộ môn:
            <select value={filterDeptId} onChange={e => { setFilterDeptId(e.target.value); setFilterCourseCode(''); }}>
              <option value="">Tất cả bộ môn</option>
              {departments.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </label>
          <label style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: '0.5rem' }}>
            Tra cứu theo môn:
            <select value={filterCourseCode} onChange={e => setFilterCourseCode(e.target.value)}>
              <option value="">Tất cả môn học</option>
              {filterSubjectOptions.map(s => (
                <option key={s.id} value={s.courseCode}>{s.courseCode} — {s.courseName}</option>
              ))}
            </select>
          </label>
        </div>

        {filterCourseCode && (
          <p className="info-banner" style={{ marginTop: '0.75rem', marginBottom: 0 }}>
            Môn <strong>{filterCourseCode}</strong> hiện có <strong>{visibleTeachers.length}</strong> giảng viên có thể giảng dạy
            {visibleTeachers.length > 0 && `: ${visibleTeachers.map(t => `${t.teacherName} (${t.teacherId})`).join(', ')}`}.
          </p>
        )}

        <div className="table-scroll catalog-table">
          <table>
            <thead>
              <tr><th>Mã GV</th><th>Họ tên</th><th>Bộ môn / Loại</th><th>Tài khoản &amp; MK mặc định</th><th>Các môn có thể dạy</th><th>Thao tác</th></tr>
            </thead>
            <tbody>
              {!visibleTeachers.length && <tr><td colSpan={6}>Không có giảng viên phù hợp.</td></tr>}
              {visibleTeachers.map(t => (
                <tr key={t.teacherId}>
                  <td><strong>{t.teacherId}</strong></td>
                  <td>{t.teacherName}</td>
                  <td>
                    <div>{t.departmentName || <span className="muted-text">Chưa có bộ môn</span>}</div>
                    <small className="badge muted" style={{ marginTop: '4px' }}>{teacherTypeLabel(t.teacherType)}</small>
                  </td>
                  <td>
                    <div>TK: <code>{t.username}</code></div>
                    {t.defaultPassword && <div>MK: <code>{t.defaultPassword}</code></div>}
                  </td>
                  <td>
                    {(t.subjects || []).map(s => (
                      <div key={s.id || `${s.courseCode}-${s.cohort}`} style={{ fontSize: '0.88rem', marginBottom: '4px' }}>
                        <code>{s.courseCode}</code> — {s.courseName}{' '}
                        {s.id && (
                          <button type="button" className="icon-button" style={{ padding: '2px', display: 'inline-grid' }} onClick={() => handleDeleteTeacherAssignment(s.id)} title="Gỡ môn">
                            <Trash2 size={12} />
                          </button>
                        )}
                      </div>
                    ))}
                    {!(t.subjects || []).length && <span className="muted-text">Chưa khai báo môn</span>}
                  </td>
                  <td>
                    <button
                      type="button"
                      className="button compact"
                      onClick={() => {
                        setSubjectSearch('');
                        setTeacherForm({
                          teacherId: t.teacherId,
                          teacherName: t.teacherName || '',
                          departmentId: t.departmentId ? String(t.departmentId) : (departments[0]?.id ? String(departments[0].id) : ''),
                          teacherType: t.teacherType || 'GIANG_VIEN',
                          selectedCodes: (t.subjects || []).map(s => s.courseCode.toUpperCase()),
                        });
                      }}
                    >
                      <Edit3 size={14} /> Sửa
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}