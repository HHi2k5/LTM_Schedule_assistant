import React, { useEffect, useState } from 'react';
import { Upload, Download, Calendar, CheckCircle2, AlertTriangle, Search, Trash2, UserCheck } from 'lucide-react';
import { api, addDays } from './schedule';
import { planWorkbook } from './autoScheduleWorkbook';
import { scheduledWorkbook } from './scheduleExport';
import { firstActiveWeek, isSavedAutoResult, unscheduledClasses, validateAutoResult, validateFile, validateSchool } from './workflow';
import VisitingSchedulePanel from './VisitingSchedulePanel';
import FormError from './FormError';

export default function AutoSchedulePage({ semesterStart, onScheduled, onViewTeacherSchedule, onNavigateAssignments }) {
  const [schoolId, setSchoolId] = useState('PTIT');
  const [schoolName, setSchoolName] = useState('Khoa Công nghệ Thông tin - PTIT');
  const [startDate, setStartDate] = useState(semesterStart || '2026-08-10');

  const [planFile, setPlanFile] = useState(null);
  const [roomFile, setRoomFile] = useState(null);
  const [savedRooms, setSavedRooms] = useState([]);
  const [savedSubjectsCount, setSavedSubjectsCount] = useState(0);

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [infoMessage, setInfoMessage] = useState('');
  const [result, setResult] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState('');

  const [filterText, setFilterText] = useState('');
  const [sessionFilter, setSessionFilter] = useState('ALL');

  const samplePlans = [
    { courseCode: '61FIT3DBS', courseName: 'Cơ sở dữ liệu', classType: 'LT', classSize: 60, cohort: '2024', numClasses: 2, studyStartDate: startDate, studyEndDate: addDays(startDate, 105), credits: 3, totalPeriods: 30 },
    { courseCode: '61FIT3DBS', courseName: 'Cơ sở dữ liệu', classType: 'TH', classSize: 30, cohort: '2024', numClasses: 4, studyStartDate: startDate, studyEndDate: addDays(startDate, 105), credits: 3, totalPeriods: 15 },
    { courseCode: '61FIT3CGR', courseName: 'Đồ họa máy tính', classType: 'LT', classSize: 90, cohort: '2024', numClasses: 1, studyStartDate: startDate, studyEndDate: addDays(startDate, 105), credits: 3, totalPeriods: 30 },
    { courseCode: '61FIT3CGR', courseName: 'Đồ họa máy tính', classType: 'TH', classSize: 30, cohort: '2024', numClasses: 3, studyStartDate: startDate, studyEndDate: addDays(startDate, 105), credits: 3, totalPeriods: 15 },
  ];

  useEffect(() => {
    if (!schoolId.trim()) return;
    loadCatalog(schoolId.trim());
  }, [schoolId]);

  async function loadCatalog(code) {
    try {
      const [roomsData, subjectsData] = await Promise.all([
        api(`/rooms?schoolId=${encodeURIComponent(code)}`),
        api(`/subjects?schoolId=${encodeURIComponent(code)}`),
      ]);
      setSavedRooms(Array.isArray(roomsData) ? roomsData : []);
      setSavedSubjectsCount(Array.isArray(subjectsData) ? subjectsData.length : 0);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleClearDepartmentSchedule() {
    if (!window.confirm(`Bạn có chắc chắn muốn XÓA TOÀN BỘ lịch đã xếp của khoa "${schoolName}" (${schoolId})?`)) {
      return;
    }
    setBusy(true);
    setError('');
    setInfoMessage('');
    try {
      const res = await api(`/department-schedule?schoolId=${encodeURIComponent(schoolId.trim())}`, {
        method: 'DELETE',
      });
      setResult(null);
      setInfoMessage(res.message || 'Đã xóa toàn bộ lịch cũ của khoa!');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function downloadPlanTemplate() {
    const workbook = planWorkbook(samplePlans);
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mau-ke-hoach-mo-lop-khoa.xlsx';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function handleScheduleSubmit(event) {
    event.preventDefault();
    if (busy || exporting) return;
    try {
      validateSchool(schoolId, schoolName, startDate);
      validateFile(planFile, 'Kế hoạch mở lớp');
      if (roomFile) validateFile(roomFile, 'Danh mục phòng học');
      if (!roomFile && !savedRooms.length) {
        throw new Error('Khoa chưa có phòng học nào. Hãy thêm phòng ở trang Loại phòng & Phòng học hoặc chọn file Excel phòng học.');
      }
    } catch (err) {
      setError(err.message);
      return;
    }

    setBusy(true);
    setError('');
    setInfoMessage('');
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('planFile', planFile);
      if (roomFile) formData.append('roomFile', roomFile);
      formData.append('schoolId', schoolId.trim());
      formData.append('schoolName', schoolName.trim());
      formData.append('semesterStartDate', startDate);

      const response = await api('/auto-generate-3files', {
        method: 'POST',
        body: formData,
      });

      validateAutoResult(response);
      setResult(response);
      if (roomFile) await loadCatalog(schoolId.trim());
      if (response.saved) onScheduled?.(response);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function exportResultToExcel() {
    if (busy || exporting || !result) return;
    setExporting(true);
    setExportError('');
    try {
      // Các lớp bước 1 chưa phân công GV có teacherId = null; chuẩn hóa để xuất Excel hợp lệ.
      const normalized = {
        ...result,
        scheduledClasses: (result.scheduledClasses || []).map(slot => ({
          ...slot,
          teacherId: slot.teacherId || 'CHUA_PHAN_CONG',
          teacherName: slot.teacherName || 'Chưa phân công',
        })),
      };
      const { workbook, filename } = scheduledWorkbook(normalized);
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      setExportError(err.message);
    } finally {
      setExporting(false);
    }
  }

  const saved = isSavedAutoResult(result);
  const unassigned = unscheduledClasses(result);
  const canExport = Boolean(result?.scheduledClasses?.length || unassigned.length);
  const filteredSlots = (result?.scheduledClasses || []).filter(slot => {
    if (sessionFilter !== 'ALL' && slot.sessionType !== sessionFilter) return false;
    if (!filterText.trim()) return true;
    const q = filterText.toLocaleLowerCase('vi');
    return `${slot.teacherId || 'chưa phân công'} ${slot.teacherName || ''} ${slot.courseCode} ${slot.courseName} ${slot.room}`
      .toLocaleLowerCase('vi')
      .includes(q);
  });

  return (
    <section className="standalone-panel import-panel auto-panel" aria-busy={busy}>
      <div className="panel-title">
        <div>
          <h2>Xếp lịch lớp của Khoa vào phòng</h2>
          <p className="muted-text">
            Bước 1: Admin tải file Kế hoạch mở lớp để hệ thống tự động xếp phòng theo đúng loại phòng yêu cầu của từng môn. Bước 2: Trưởng bộ môn vào mục Phân công giảng viên để gán giảng viên dạy từng lớp.
          </p>
        </div>
        <button
          type="button"
          className="button"
          style={{ color: '#dc2626', borderColor: '#fca5a5' }}
          disabled={busy}
          onClick={handleClearDepartmentSchedule}
        >
          <Trash2 size={16} /> Xóa toàn bộ lịch cũ của Khoa
        </button>
      </div>

      <form onSubmit={handleScheduleSubmit}>
        <fieldset disabled={busy || exporting} className="import-fields">
          <label>Mã Khoa <input value={schoolId} onChange={e => setSchoolId(e.target.value)} required maxLength={50} /></label>
          <label>Tên Khoa / Đơn vị <input value={schoolName} onChange={e => setSchoolName(e.target.value)} required maxLength={255} /></label>
          <label>Ngày Thứ Hai của Tuần 1 <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} required /></label>
          <label>
            File Phòng học bổ sung (.xlsx — không bắt buộc)
            <input type="file" accept=".xlsx" onChange={e => setRoomFile(e.target.files?.[0] || null)} />
            <small>Để trống để dùng {savedRooms.length} phòng đang lưu trong hệ thống.</small>
          </label>

          <div className="file-field" style={{ gridColumn: '1 / -1' }}>
            <label htmlFor="auto-plan-file"><strong>File Danh sách mở lớp của Khoa (.xlsx)</strong></label>
            <input id="auto-plan-file" type="file" accept=".xlsx" onChange={e => setPlanFile(e.target.files?.[0] || null)} required />
            <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', marginTop: '0.4rem' }}>
              <button type="button" className="button compact" onClick={downloadPlanTemplate}><Download size={15} /> Tải mẫu Mở lớp</button>
              <small>Đang có trong hệ thống: <strong>{savedSubjectsCount} môn học</strong> · <strong>{savedRooms.length} phòng học</strong></small>
            </div>
          </div>
        </fieldset>

        <div className="import-actions" style={{ marginTop: '0.75rem' }}>
          {onNavigateAssignments && (
            <button type="button" className="button" onClick={onNavigateAssignments}>
              <UserCheck size={16} /> Mở trang Phân công giảng viên
            </button>
          )}
          <button type="submit" className="button primary" disabled={busy || !planFile}>
            <Upload size={16} /> {busy ? 'Đang xếp phòng cho các lớp…' : 'Tải File Mở Lớp & Chạy Xếp Phòng'}
          </button>
        </div>
      </form>

      <FormError message={error} />
      {infoMessage && <div role="status" className="info-banner" style={{ marginTop: '0.75rem' }}><CheckCircle2 size={18} /> {infoMessage}</div>}

      <div style={{ marginTop: '1.5rem' }}>
        <VisitingSchedulePanel
          schoolId={schoolId}
          schoolName={schoolName}
          semesterStart={startDate}
          defaultOpen={false}
          onScheduled={res => {
            setResult(res);
            setInfoMessage(res.message);
            onScheduled?.(res);
          }}
        />
      </div>

      {exportError && <p role="alert" className="error-text">{exportError}</p>}
      {result && (
        <div className="import-preview" style={{ marginTop: '1.5rem' }}>
          <div className="panel-title">
            <div>
              <h2>{saved ? <CheckCircle2 size={18} /> : <AlertTriangle size={18} />} {saved ? 'Đã lưu các lớp xếp phòng thành công' : 'Kết quả xếp lịch — chưa lưu'}</h2>
              <p>{result.message}</p>
              {result.catalogWarnings?.length > 0 && (
                <div className="import-warning" style={{ marginTop: '0.5rem' }}>
                  <AlertTriangle size={16} />
                  <span>{result.catalogWarnings.join(' | ')}</span>
                </div>
              )}
              {result.unscheduledWarnings?.length > 0 && !unassigned.length && (
                <div className="import-warning" style={{ marginTop: '0.5rem' }}>
                  <AlertTriangle size={16} />
                  <span><strong>Cảnh báo:</strong> {result.unscheduledWarnings.join(' | ')}</span>
                </div>
              )}
            </div>
            <div className="template-actions">
              <button type="button" className="button primary" disabled={busy || exporting || !canExport} onClick={exportResultToExcel}><Download size={16} /> {exporting ? 'Đang xuất Excel…' : 'Xuất Excel kết quả'}</button>
            </div>
          </div>

          {unassigned.length > 0 && (
            <section aria-label="Các lớp chưa xếp được" style={{ marginTop: '1rem' }}>
              <div role="alert" className="import-warning">
                <AlertTriangle size={18} />
                <span>Còn <strong>{unassigned.length} lớp/nhóm chưa xếp được phòng</strong>. Danh sách này có trong file Excel kết quả.</span>
              </div>
              <div className="table-scroll">
                <table>
                  <thead><tr><th>Mã môn</th><th>Học phần</th><th>Khóa</th><th>Lớp/nhóm</th><th>Loại</th><th>Tiết còn thiếu</th><th>Lý do chưa xếp</th></tr></thead>
                  <tbody>{unassigned.map((row, index) => (
                    <tr key={row.classId || index}>
                      <td>{row.courseCode}</td><td>{row.courseName || '—'}</td><td>{row.cohort}</td>
                      <td>{row.classGroup}</td><td>{row.sessionType === 'PRACTICE' ? 'TH' : 'LT'}</td>
                      <td>{row.missingPeriods}/{row.requiredPeriods}</td>
                      <td>{row.reason || 'Chưa xếp đủ lịch cho lớp/nhóm.'}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </section>
          )}

          <div className="filter-bar" style={{ marginTop: '0.75rem' }}>
            <label className="search-field">
              <Search size={17} />
              <input placeholder="Tìm theo giảng viên, môn học, phòng…" value={filterText} onChange={e => setFilterText(e.target.value)} />
            </label>
            <select value={sessionFilter} onChange={e => setSessionFilter(e.target.value)}>
              <option value="ALL">Tất cả (Lý thuyết + Thực hành)</option>
              <option value="THEORY">Lớp Lý thuyết</option>
              <option value="PRACTICE">Lớp Thực hành</option>
            </select>
          </div>

          <div className="table-scroll" style={{ marginTop: '0.75rem' }}>
            <table>
              <thead>
                <tr>
                  <th>Giảng viên</th><th>Mã môn</th><th>Học phần &amp; Nhóm</th><th>Loại lớp</th><th>Sĩ số</th><th>Phòng học</th><th>Thứ</th><th>Tiết học</th><th>Ghi chú</th><th>Xem TKB / Phân công</th>
                </tr>
              </thead>
              <tbody>
                {filteredSlots.map((slot, index) => (
                  <tr key={index}>
                    <td>
                      {slot.teacherId
                        ? <><strong>{slot.teacherId}</strong> · {slot.teacherName}</>
                        : <span className="badge muted">Chưa phân công</span>}
                    </td>
                    <td><code>{slot.courseCode}</code></td>
                    <td>{slot.courseName}</td>
                    <td><span className="badge" style={{ background: slot.sessionType === 'PRACTICE' ? '#0284c7' : '#16a34a', color: '#fff' }}>{slot.sessionType === 'PRACTICE' ? 'TH' : 'LT'}</span></td>
                    <td>{slot.studentCount} SV</td>
                    <td><strong>{slot.room}</strong></td>
                    <td>{slot.dayOfWeek === 8 ? 'CN' : `Thứ ${slot.dayOfWeek}`}</td>
                    <td>Tiết {slot.startPeriod}–{slot.startPeriod + slot.numPeriods - 1}</td>
                    <td><small className="muted-text">{slot.phaseNote || '—'}</small></td>
                    <td>
                      {slot.teacherId && onViewTeacherSchedule ? (
                        <button type="button" className="button compact" disabled={!saved} onClick={() => onViewTeacherSchedule(slot.teacherId, firstActiveWeek(result.scheduledClasses, slot.teacherId))}>
                          <Calendar size={14} /> Xem TKB
                        </button>
                      ) : onNavigateAssignments ? (
                        <button type="button" className="button compact" disabled={!saved} onClick={onNavigateAssignments}>
                          <UserCheck size={14} /> Phân công
                        </button>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </section>
  );
}