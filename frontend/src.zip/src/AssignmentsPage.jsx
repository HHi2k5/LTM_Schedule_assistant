import React, { useEffect, useState } from 'react';
import { AlertTriangle, Calendar, CheckCircle2, RefreshCw, Search, Sparkles, UserCheck, Users } from 'lucide-react';
import { api } from './schedule';
import { firstWeek, postJson, teacherTypeLabel, weekRanges } from './catalog';
import { isAdmin } from './permissions';
import VisitingSchedulePanel from './VisitingSchedulePanel';
import FormError from './FormError';

export default function AssignmentsPage({ user, scheduleRevision = 0, onViewTeacherSchedule }) {
  const admin = isAdmin(user);
  const [schoolId, setSchoolId] = useState('PTIT');
  const [departments, setDepartments] = useState([]);
  const [departmentId, setDepartmentId] = useState(admin ? '' : String(user?.departmentId || ''));
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [busyKey, setBusyKey] = useState('');
  const [autoResult, setAutoResult] = useState(null);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const school = schoolId.trim() || 'PTIT';

  useEffect(() => {
    if (!admin) {
      setDepartmentId(String(user?.departmentId || ''));
    }
  }, [admin, user?.departmentId]);

  useEffect(() => {
    let active = true;
    api(`/departments?schoolId=${encodeURIComponent(school)}`)
      .then(list => {
        if (!active) return;
        const items = Array.isArray(list) ? list : [];
        setDepartments(items);
        if (admin && !departmentId && items.length === 1) {
          setDepartmentId(String(items[0].id));
        }
      })
      .catch(err => { if (active) setError(err.message); });
    return () => { active = false; };
  }, [school, admin]);

  async function loadOverview() {
    setLoading(true);
    setError('');
    try {
      const deptParam = departmentId ? `&departmentId=${encodeURIComponent(departmentId)}` : '';
      const data = await api(`/assignments?schoolId=${encodeURIComponent(school)}${deptParam}`);
      setOverview(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadOverview();
  }, [school, departmentId, scheduleRevision]);

  async function handleAssign(classId, teacherId) {
    setBusyKey(classId);
    setError('');
    setInfo('');
    try {
      const res = await postJson('/assignments/assign', {
        schoolId: school,
        classId,
        teacherId: teacherId || null,
      });
      setInfo(res.message);
      await loadOverview();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyKey('');
    }
  }

  async function handleAutoAssign() {
    if (!departmentId) {
      setError('Vui lòng chọn một Bộ môn cụ thể trước khi chạy tự phân công.');
      return;
    }
    setBusyKey('__AUTO__');
    setError('');
    setInfo('');
    setAutoResult(null);
    try {
      const res = await postJson('/assignments/auto', {
        schoolId: school,
        departmentId: Number(departmentId),
      });
      setAutoResult(res);
      setInfo(res.message);
      await loadOverview();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyKey('');
    }
  }

  const classes = overview?.classes || [];
  const teachers = overview?.teachers || [];
  const unassignedCount = classes.filter(c => !c.teacherId).length;

  const visibleClasses = classes.filter(row => {
    if (statusFilter === 'UNASSIGNED' && row.teacherId) return false;
    if (statusFilter === 'ASSIGNED' && !row.teacherId) return false;
    if (!query.trim()) return true;
    const q = query.toLocaleLowerCase('vi');
    return `${row.courseCode} ${row.courseName} ${row.label} ${row.teacherName || ''} ${row.teacherId || ''}`
      .toLocaleLowerCase('vi')
      .includes(q);
  });

  const activeDepartmentName = departments.find(d => String(d.id) === String(departmentId))?.name
    || user?.departmentName
    || 'Tất cả bộ môn';

  return (
    <section className="standalone-panel import-panel auto-panel">
      <div className="panel-title">
        <div>
          <h2>Phân công giảng viên</h2>
          <p className="muted-text">
            {admin
              ? 'Xem và phân công giảng viên vào các lớp khoa đã xếp phòng.'
              : `Bộ môn ${activeDepartmentName}: phân công giảng viên thuộc bộ môn vào các lớp đã xếp phòng (tự động kiểm tra trùng giờ).`}
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'end' }}>
          {admin && (
            <>
              <label className="catalog-school">
                Mã Khoa
                <input value={schoolId} onChange={e => setSchoolId(e.target.value)} maxLength={50} />
              </label>
              <label>
                Lọc bộ môn
                <select value={departmentId} onChange={e => setDepartmentId(e.target.value)}>
                  <option value="">Tất cả bộ môn</option>
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>{d.code} — {d.name}</option>
                  ))}
                </select>
              </label>
            </>
          )}
          <button type="button" className="button" disabled={loading} onClick={loadOverview}>
            <RefreshCw size={15} /> Làm mới
          </button>
          <button type="button" className="button primary" disabled={busyKey === '__AUTO__' || !departmentId || !unassignedCount} onClick={handleAutoAssign}>
            <Sparkles size={15} /> {busyKey === '__AUTO__' ? 'Đang phân công…' : `Tự phân công (${unassignedCount} lớp trống)`}
          </button>
        </div>
      </div>

      <FormError message={error} />
      {info && <div role="status" className="info-banner catalog-info"><CheckCircle2 size={18} /> {info}</div>}

      {autoResult?.remaining?.length > 0 && (
        <div className="import-warning">
          <AlertTriangle size={18} />
          <div>
            <strong>Còn {autoResult.remaining.length} lớp chưa tự phân công được:</strong>
            <ul style={{ margin: '6px 0 0', paddingLeft: '18px' }}>
              {autoResult.remaining.map(item => (
                <li key={item.classId}>{item.label}: {item.reason}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* TẢI GIẢNG DẠY HIỆN TẠI TRONG BỘ MÔN */}
      <div className="catalog-card">
        <h3><Users size={18} /> Khối lượng giảng dạy của giảng viên ({teachers.length})</h3>
        <div className="table-scroll catalog-table">
          <table>
            <thead>
              <tr><th>Mã GV</th><th>Họ tên</th><th>Loại GV</th><th>Số lớp đang nhận</th><th>Tổng số tiết</th><th>Lịch tuần</th></tr>
            </thead>
            <tbody>
              {!teachers.length && <tr><td colSpan={6}>Chưa có giảng viên thuộc phạm vi bộ môn này.</td></tr>}
              {teachers.map(t => (
                <tr key={t.teacherId}>
                  <td><strong>{t.teacherId}</strong></td>
                  <td>{t.teacherName}</td>
                  <td>{teacherTypeLabel(t.teacherType)}</td>
                  <td><strong>{t.classes}</strong> lớp</td>
                  <td>{t.periods} tiết</td>
                  <td>
                    {onViewTeacherSchedule && (
                      <button type="button" className="button compact" onClick={() => onViewTeacherSchedule(t.teacherId, 1)}>
                        <Calendar size={14} /> Xem TKB
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DANH SÁCH LỚP CẦN PHÂN CÔNG */}
      <div className="catalog-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
          <h3><UserCheck size={18} /> Các lớp đã xếp phòng ({visibleClasses.length} / {classes.length} · còn {unassignedCount} chưa phân công)</h3>
        </div>

        <div className="filter-bar" style={{ padding: '0.75rem 0 0' }}>
          <label className="search-field">
            <Search size={17} />
            <input placeholder="Tìm theo mã môn, tên môn, lớp, giảng viên…" value={query} onChange={e => setQuery(e.target.value)} />
          </label>
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="ALL">Tất cả trạng thái</option>
            <option value="UNASSIGNED">Chưa phân công ({unassignedCount})</option>
            <option value="ASSIGNED">Đã phân công ({classes.length - unassignedCount})</option>
          </select>
        </div>

        <div className="table-scroll catalog-table">
          <table>
            <thead>
              <tr>
                <th>Môn học &amp; Lớp</th>
                <th>Lịch phòng đã xếp</th>
                <th>Giảng viên phân công</th>
                <th>Chọn giảng viên dạy</th>
              </tr>
            </thead>
            <tbody>
              {!visibleClasses.length && (
                <tr><td colSpan={4}>{loading ? 'Đang tải danh sách lớp…' : 'Chưa có lớp nào cần phân công trong bộ môn này.'}</td></tr>
              )}
              {visibleClasses.map(row => {
                const isBusy = busyKey === row.classId;
                const firstActive = row.sessions?.length
                  ? Math.min(...row.sessions.map(s => firstWeek(s.weekSchedule)).filter(Boolean))
                  : 1;
                return (
                  <tr key={row.classId} className={!row.teacherId ? 'assign-row-unassigned' : ''}>
                    <td style={{ whiteSpace: 'normal', minWidth: '220px' }}>
                      <div>
                        <code>{row.courseCode}</code>{' '}
                        <span className="badge" style={{ background: row.sessionType === 'PRACTICE' ? '#0284c7' : '#16a34a', color: '#fff' }}>
                          {row.sessionType === 'PRACTICE' ? 'TH' : 'LT'}
                        </span>
                      </div>
                      <strong style={{ display: 'block', marginTop: '4px' }}>{row.courseName} — {row.label}</strong>
                      <small className="muted-text">{row.totalPeriods} tiết{row.departmentName ? ` · ${row.departmentName}` : ''}</small>
                    </td>
                    <td style={{ whiteSpace: 'normal', minWidth: '240px' }}>
                      {(row.sessions || []).map((s, idx) => (
                        <div key={idx} style={{ fontSize: '0.88rem', marginBottom: '3px' }}>
                          {s.dayOfWeek === 8 ? 'CN' : `Thứ ${s.dayOfWeek}`} · Tiết {s.startPeriod}–{s.startPeriod + s.numPeriods - 1} · Phòng <strong>{s.room}</strong> · Tuần {weekRanges(s.weekSchedule)}
                        </div>
                      ))}
                    </td>
                    <td>
                      {row.teacherId ? (
                        <div>
                          <strong>{row.teacherName}</strong> ({row.teacherId})
                          {onViewTeacherSchedule && (
                            <div style={{ marginTop: '4px' }}>
                              <button type="button" className="button compact" onClick={() => onViewTeacherSchedule(row.teacherId, firstActive || 1)}>
                                <Calendar size={13} /> Xem TKB
                              </button>
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="badge muted">Chưa phân công</span>
                      )}
                    </td>
                    <td style={{ minWidth: '260px' }}>
                      <select
                        disabled={isBusy}
                        value={row.teacherId || ''}
                        onChange={e => handleAssign(row.classId, e.target.value)}
                        style={{ width: '100%' }}
                      >
                        <option value="">-- Chưa phân công (trả về kho lớp) --</option>
                        {(row.candidates || []).map(c => {
                          const disabled = Boolean(c.blockedReason) && c.teacherId !== row.teacherId;
                          return (
                            <option key={c.teacherId} value={c.teacherId} disabled={disabled}>
                              {c.teacherName} ({c.teacherId}) · {teacherTypeLabel(c.teacherType)}
                              {c.blockedReason ? ` — [Bị chặn: ${c.blockedReason}]` : ''}
                            </option>
                          );
                        })}
                      </select>
                      {!row.candidates?.length && (
                        <small className="error-text" style={{ display: 'block', marginTop: '4px' }}>
                          Chưa có GV thuộc bộ môn có thể dạy môn {row.courseCode}.
                        </small>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* XẾP LỊCH BỔ SUNG CHO GIẢNG VIÊN THỈNH GIẢNG */}
      <div style={{ marginTop: '1.5rem' }}>
        <VisitingSchedulePanel
          schoolId={school}
          semesterStart={overview?.semesterStartDate || user?.semesterStartDate || '2026-08-10'}
          departmentId={departmentId || null}
          defaultOpen={false}
          onScheduled={() => loadOverview()}
        />
      </div>
    </section>
  );
}