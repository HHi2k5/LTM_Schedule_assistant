import React, { useEffect, useState } from 'react';
import { Plus, Trash2, UserPlus, CheckCircle2 } from 'lucide-react';
import { api, addDays } from './schedule';
import FormError from './FormError';

function partitionPracticePeriods(total) {
  const n = Number(total);
  if (!Number.isInteger(n) || n < 3) return null;
  for (let n4 = Math.floor(n / 4); n4 >= 0; n4--) {
    const rem = n - 4 * n4;
    if (rem % 3 === 0) {
      const n3 = rem / 3;
      return [...Array(n4).fill(4), ...Array(n3).fill(3)];
    }
  }
  return null;
}

const emptyRow = () => ({
  courseCode: '',
  courseName: '',
  cohort: '2024',
  classGroup: 'Lớp 01',
  sessionType: 'THEORY',
  studentCount: 60,
  requiredPeriods: 30,
});

export default function VisitingSchedulePanel({
  schoolId = 'PTIT',
  schoolName = 'Khoa Công nghệ Thông tin - PTIT',
  semesterStart = '2026-08-10',
  departmentId = null,
  onScheduled,
  defaultOpen = false,
}) {
  const [subjects, setSubjects] = useState([]);
  const [savedTeachers, setSavedTeachers] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const [form, setForm] = useState({
    teacherId: '',
    teacherName: '',
    assignments: [emptyRow()],
    studyStartDate: semesterStart,
    studyEndDate: addDays(semesterStart, 105),
    busyDaysOfWeek: [],
    busyDatesText: '',
  });

  useEffect(() => {
    setForm(prev => ({
      ...prev,
      studyStartDate: prev.studyStartDate || semesterStart,
      studyEndDate: prev.studyEndDate || addDays(semesterStart, 105),
    }));
  }, [semesterStart]);

  useEffect(() => {
    const code = (schoolId || 'PTIT').trim();
    if (!code) return;
    let active = true;
    const deptQuery = departmentId ? `&departmentId=${departmentId}` : '';
    Promise.all([
      api(`/subjects?schoolId=${encodeURIComponent(code)}${deptQuery}`),
      api(`/teacher-subjects?schoolId=${encodeURIComponent(code)}${deptQuery}`),
    ])
      .then(([subData, teacherData]) => {
        if (!active) return;
        setSubjects(Array.isArray(subData) ? subData : []);
        setSavedTeachers(Array.isArray(teacherData) ? teacherData : []);
      })
      .catch(err => {
        if (active) setError(err.message);
      });
    return () => { active = false; };
  }, [schoolId, departmentId]);

  function handleTeacherIdChange(val) {
    const upper = val.toUpperCase();
    const existing = savedTeachers.find(t => t.teacherId.toUpperCase() === upper.trim());
    setForm(prev => ({
      ...prev,
      teacherId: val,
      teacherName: existing ? existing.teacherName : prev.teacherName,
    }));
  }

  function addRow() {
    setForm(prev => ({
      ...prev,
      assignments: [...prev.assignments, { ...emptyRow(), classGroup: `Lớp 0${prev.assignments.length + 1}` }],
    }));
  }

  function removeRow(idx) {
    if (form.assignments.length === 1) return;
    setForm(prev => ({
      ...prev,
      assignments: prev.assignments.filter((_, i) => i !== idx),
    }));
  }

  function updateRow(idx, field, value) {
    setForm(prev => {
      const next = [...prev.assignments];
      if (field === 'courseCode') {
        const matched = subjects.find(s => s.courseCode.toUpperCase() === String(value).toUpperCase());
        next[idx] = {
          ...next[idx],
          courseCode: value,
          courseName: matched ? matched.courseName : next[idx].courseName,
        };
      } else {
        next[idx] = { ...next[idx], [field]: value };
      }
      return { ...prev, assignments: next };
    });
  }

  function toggleBusyDay(day) {
    setForm(prev => {
      const exists = prev.busyDaysOfWeek.includes(day);
      return {
        ...prev,
        busyDaysOfWeek: exists ? prev.busyDaysOfWeek.filter(d => d !== day) : [...prev.busyDaysOfWeek, day],
      };
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (busy) return;
    setError('');
    setInfo('');

    for (let i = 0; i < form.assignments.length; i++) {
      const a = form.assignments[i];
      if (!a.courseCode) {
        setError(`Dòng ${i + 1}: Vui lòng chọn môn học thuộc danh mục bộ môn.`);
        return;
      }
      if (a.sessionType === 'PRACTICE' && !partitionPracticePeriods(a.requiredPeriods)) {
        setError(`Môn ${a.courseCode}: Tổng tiết thực hành (${a.requiredPeriods}) không thể chia thành các buổi 3–4 tiết.`);
        return;
      }
    }

    setBusy(true);
    try {
      const response = await api('/visiting-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          schoolId: schoolId.trim(),
          schoolName: schoolName.trim(),
          semesterStartDate: semesterStart,
          assignments: form.assignments.map(a => ({
            ...a,
            studentCount: Number(a.studentCount),
            requiredPeriods: Number(a.requiredPeriods),
          })),
        }),
      });
      if (response.saved) {
        setInfo(response.message);
        onScheduled?.(response);
      } else {
        setError(response.message || 'Chưa lưu lịch thỉnh giảng.');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <details open={defaultOpen} className="visiting-panel">
      <summary>
        <UserPlus size={17} style={{ verticalAlign: 'middle' }} /> Xếp lịch bổ sung cho Giảng viên Thỉnh giảng (Đảm nhận nhiều môn, nhiều lớp)
      </summary>
      <p className="muted-text" style={{ marginTop: '0.45rem' }}>
        Chọn các môn học thuộc danh mục bộ môn để xếp phòng và thời khóa biểu rải đều cho giảng viên thỉnh giảng, tự động tránh trùng phòng và ngày bận.
      </p>

      <FormError message={error} />
      {info && <div role="status" className="info-banner"><CheckCircle2 size={18} /> {info}</div>}

      <form onSubmit={handleSubmit} style={{ marginTop: '0.75rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '0.6rem', marginBottom: '0.75rem' }}>
          <label>
            Mã GV thỉnh giảng
            <input required placeholder="VD: GV_TG01" value={form.teacherId} onChange={e => handleTeacherIdChange(e.target.value)} />
          </label>
          <label>
            Tên GV thỉnh giảng
            <input required placeholder="VD: PGS.TS Trần Văn B" value={form.teacherName} onChange={e => setForm({ ...form, teacherName: e.target.value })} />
          </label>
          <label>
            Từ ngày học
            <input type="date" required value={form.studyStartDate} onChange={e => setForm({ ...form, studyStartDate: e.target.value })} />
          </label>
          <label>
            Đến ngày học
            <input type="date" required value={form.studyEndDate} onChange={e => setForm({ ...form, studyEndDate: e.target.value })} />
          </label>
        </div>

        <h4>Danh sách các môn học / lớp học phân công</h4>
        {!subjects.length && (
          <p className="import-warning">
            Chưa có môn học nào trong danh mục bộ môn. Hãy tạo môn ở trang Bộ môn &amp; Môn học trước khi xếp thỉnh giảng.
          </p>
        )}

        {form.assignments.map((asg, idx) => (
          <div key={idx} className="visiting-assignment">
            <label>
              Môn học (trong bộ môn)
              <select required value={asg.courseCode} onChange={e => updateRow(idx, 'courseCode', e.target.value)}>
                <option value="">-- Chọn môn học --</option>
                {subjects.map(s => (
                  <option key={s.id} value={s.courseCode}>{s.courseCode} — {s.courseName}</option>
                ))}
              </select>
            </label>
            <label>
              Tên học phần
              <input readOnly value={asg.courseName} placeholder="Tự điền theo mã môn" />
            </label>
            <label>
              Khóa
              <input required placeholder="2024" value={asg.cohort} onChange={e => updateRow(idx, 'cohort', e.target.value)} />
            </label>
            <label>
              Lớp / Nhóm
              <input required placeholder="Lớp 01" value={asg.classGroup} onChange={e => updateRow(idx, 'classGroup', e.target.value)} />
            </label>
            <label>
              Loại
              <select value={asg.sessionType} onChange={e => updateRow(idx, 'sessionType', e.target.value)}>
                <option value="THEORY">Lý thuyết</option>
                <option value="PRACTICE">Thực hành</option>
              </select>
            </label>
            <label>
              Sĩ số
              <input type="number" min={1} required value={asg.studentCount} onChange={e => updateRow(idx, 'studentCount', e.target.value)} />
            </label>
            <label>
              Tổng tiết
              <input type="number" min={1} required value={asg.requiredPeriods} onChange={e => updateRow(idx, 'requiredPeriods', e.target.value)} />
            </label>
            <button type="button" className="icon-button" onClick={() => removeRow(idx)} disabled={form.assignments.length === 1} title="Xóa dòng này">
              <Trash2 size={16} />
            </button>
          </div>
        ))}

        <button type="button" className="button compact" onClick={addRow} style={{ marginBottom: '1rem' }}>
          <Plus size={14} /> Thêm môn / lớp khác
        </button>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.75rem', alignItems: 'center' }}>
          <strong>Các thứ bận cố định trong tuần:</strong>
          {[2, 3, 4, 5, 6, 7].map(d => (
            <label key={d} style={{ display: 'inline-flex', flexDirection: 'row', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
              <input type="checkbox" checked={form.busyDaysOfWeek.includes(d)} onChange={() => toggleBusyDay(d)} />
              Thứ {d}
            </label>
          ))}
        </div>

        <div style={{ marginTop: '0.6rem', display: 'flex', gap: '0.75rem', alignItems: 'end', flexWrap: 'wrap' }}>
          <label style={{ flex: 1, minWidth: '260px' }}>
            Hoặc ngày bận cụ thể (YYYY-MM-DD, cách nhau dấu phẩy)
            <input placeholder="VD: 2026-08-18, 2026-08-25" value={form.busyDatesText} onChange={e => setForm({ ...form, busyDatesText: e.target.value })} />
          </label>
          <button type="submit" className="button primary" disabled={busy || !subjects.length}>
            <UserPlus size={16} /> {busy ? 'Đang xếp lịch…' : 'Xếp phòng & Lưu lịch Thỉnh giảng'}
          </button>
        </div>
      </form>
    </details>
  );
}