import ExcelJS from 'exceljs';
import { addDays, clock, isMonday, minutes } from './schedule.js';
import { unscheduledClasses } from './workflow.js';

export const scheduleHeaders = ['Mã MH', 'Tên môn học', 'Nhóm tổ', 'Số tín chỉ', 'Thứ', 'Tiết bắt đầu', 'Số tiết', 'Phòng', 'Thời gian học:', 'Mã GV', 'Tên GV'];
const exportDate = (value, fullYear) => `${value.slice(8)}/${value.slice(5, 7)}/${fullYear ? value.slice(0, 4) : value.slice(2, 4)}`;
const nonempty = value => typeof value === 'string' && value.trim().length > 0;
const integer = (value, min, max) => Number.isInteger(value) && value >= min && value <= max;

export function scheduledRows(result) {
  if (!isMonday(result?.semesterStartDate)) throw new Error('Kết quả thiếu mốc Thứ Hai của tuần 1 hợp lệ.');
  if (!Array.isArray(result.scheduledClasses) || (!result.scheduledClasses.length && !unscheduledClasses(result).length)) {
    throw new Error('Chưa có kết quả xếp lịch để xuất Excel.');
  }
  if (!Array.isArray(result.periods) || !result.periods.length) throw new Error('Kết quả thiếu bảng giờ tiết.');
  const periods = new Map();
  for (const period of result.periods) {
    const validTime = value => /^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/.test(value || '');
    if (!integer(period.period, 1, 30) || periods.has(period.period) || !validTime(period.start) || !validTime(period.end) || minutes(period.end) <= minutes(period.start)) {
      throw new Error('Bảng giờ tiết trong kết quả không hợp lệ.');
    }
    periods.set(period.period, period);
  }
  const rows = [];
  for (const slot of result.scheduledClasses) {
    if (![slot.teacherId, slot.teacherName, slot.courseCode, slot.baseCourseName, slot.classGroup, slot.room].every(nonempty)
        || !integer(slot.dayOfWeek, 2, 8) || !integer(slot.startPeriod, 1, 30) || !integer(slot.numPeriods, 1, 30)
        || (slot.credits != null && !integer(slot.credits, 1, 30))
        || !/^[a-zA-Z0-9 -]{1,100}$/.test(slot.weekSchedule || '') || !/[^- ]/.test(slot.weekSchedule)) {
      throw new Error('Một lớp thiếu hoặc sai dữ liệu giảng viên, môn học, tiết hoặc tuần.');
    }
    for (let p = slot.startPeriod; p < slot.startPeriod + slot.numPeriods; p++) {
      if (!periods.has(p)) throw new Error(`Lớp ${slot.courseCode} thiếu giờ của tiết ${p}.`);
    }
    const weeks = slot.weekSchedule;
    for (let i = 0; i < weeks.length; i++) {
      if (weeks[i] === '-' || weeks[i] === ' ') continue;
      const first = i;
      while (i + 1 < weeks.length && weeks[i + 1] !== '-' && weeks[i + 1] !== ' ') i++;
      const start = addDays(result.semesterStartDate, first * 7 + slot.dayOfWeek - 2);
      const end = addDays(result.semesterStartDate, i * 7 + slot.dayOfWeek - 2);
      rows.push({ slot, firstWeek: first, values: [slot.courseCode, slot.baseCourseName, slot.classGroup,
        slot.credits ?? null, slot.dayOfWeek, slot.startPeriod, slot.numPeriods, slot.room,
        `${exportDate(start, Boolean(slot.classId))} đến ${exportDate(end, Boolean(slot.classId))}`, slot.teacherId, slot.teacherName] });
    }
  }
  rows.sort((a, b) => {
    for (const key of ['teacherId', 'courseCode', 'classGroup']) {
      const compared = a.slot[key].localeCompare(b.slot[key], 'vi', { numeric: true });
      if (compared) return compared;
    }
    return a.slot.dayOfWeek - b.slot.dayOfWeek || a.firstWeek - b.firstWeek || a.slot.startPeriod - b.slot.startPeriod;
  });
  return rows.map(row => row.values);
}

export function scheduledWorkbook(result) {
  const rows = scheduledRows(result);
  const workbook = new ExcelJS.Workbook();
  const courses = workbook.addWorksheet('MonHoc');
  courses.addRow(scheduleHeaders);
  rows.forEach(row => courses.addRow(row));
  courses.columns.forEach((column, i) => { column.width = [18, 48, 12, 12, 8, 16, 12, 16, 32, 18, 28][i]; });
  [1, 3, 9, 10, 11].forEach(column => { courses.getColumn(column).numFmt = '@'; });
  const periods = workbook.addWorksheet('TietHoc');
  periods.addRow(['period', 'start', 'end']);
  [...result.periods].sort((a, b) => a.period - b.period)
    .forEach(period => periods.addRow([period.period, clock(period.start), clock(period.end)]));
  periods.columns.forEach(column => { column.width = 16; });
  const sheets = [courses, periods];
  if (result.teacherAllocations?.length) {
    const summary = workbook.addWorksheet('PhanCongGiangVien');
    summary.addRow(['Mã môn', 'Khóa', 'Mã GV', 'Tên GV', 'Loại LT/TH', 'Trọng số', 'Mục tiêu lớp/nhóm', 'Đã giao đủ tiết', 'Tiết đã xếp']);
    result.teacherAllocations.forEach(a => summary.addRow([a.courseCode, a.cohort, a.teacherId, a.teacherName, a.sessionType,
      a.weight, a.targetClasses, a.assignedClasses, a.scheduledPeriods]));
    summary.columns.forEach(column => { column.width = 22; });
    sheets.push(summary);
  }
  if (result.classWorkloads?.length) {
    const workloads = workbook.addWorksheet('KhoiLuongLopNhom');
    workloads.addRow(['ID lớp/nhóm', 'Mã môn', 'Khóa', 'Lớp/nhóm', 'Loại LT/TH', 'Mã GV', 'Tổng tiết yêu cầu', 'Tiết đã xếp', 'Tiết còn thiếu']);
    result.classWorkloads.forEach(w => workloads.addRow([w.classId, w.courseCode, w.cohort, w.classGroup, w.sessionType,
      w.teacherId || '', w.requiredPeriods, w.scheduledPeriods, w.missingPeriods]));
    workloads.columns.forEach(column => { column.width = 24; });
    sheets.push(workloads);
  }
  const unassigned = unscheduledClasses(result);
  if (unassigned.length) {
    const missing = workbook.addWorksheet('LopChuaXep');
    missing.addRow(['ID lớp/nhóm', 'Mã môn', 'Tên học phần', 'Khóa', 'Lớp/nhóm', 'Loại LT/TH', 'Tổng tiết yêu cầu', 'Tiết còn thiếu', 'Lý do']);
    unassigned.forEach(row => missing.addRow([row.classId, row.courseCode, row.courseName || '', row.cohort,
      row.classGroup, row.sessionType === 'PRACTICE' ? 'TH' : 'LT', row.requiredPeriods, row.missingPeriods,
      row.reason || 'Chưa xếp đủ lịch cho lớp/nhóm.']));
    missing.columns.forEach((column, i) => { column.width = i === 8 ? 65 : 24; });
    sheets.push(missing);
  }
  if (result.unscheduledWarnings?.length) {
    const warnings = workbook.addWorksheet('CanhBao');
    warnings.addRow(['Thông báo xếp lịch']);
    result.unscheduledWarnings.forEach(warning => warnings.addRow([warning]));
    warnings.getColumn(1).width = 100;
    sheets.push(warnings);
  }
  for (const sheet of sheets) {
    sheet.getRow(1).font = { bold: true };
    sheet.views = [{ state: 'frozen', ySplit: 1 }];
    sheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: sheet.rowCount, column: sheet.columnCount } };
  }
  const school = String(result.schoolId || 'truong').replace(/[^a-zA-Z0-9_-]/g, '_');
  return { workbook, filename: `lich-da-xep-${school}-${result.semesterStartDate}.xlsx`,
    missingCredits: result.scheduledClasses.some(slot => slot.credits == null), rowCount: rows.length };
}
